#!/usr/bin/python

import sys
import shutil
import os
import fileinput
import time


if len(sys.argv) < 4:
	exitWithError('Argument list does not contain enough arguments')

outputFileName = sys.argv[1]
rootPath = sys.argv[2]
projectName = sys.argv[3]
assetDepot = sys.argv[4]


print 'Creating unity project : ' + projectName

os.system("/Applications/Unity/Unity.app/Contents/MacOS/Unity -quit -batchmode -createProject " + rootPath + projectName)

time.sleep(20)



print 'Copying Assets:'
print 'from ' + rootPath + assetDepot + '/Assets'
print 'to ' + rootPath + projectName + '/Assets'

shutil.rmtree(rootPath + projectName + '/Assets')
shutil.copytree( rootPath + assetDepot + '/Assets', rootPath + projectName + '/Assets')


print 'opening:' + rootPath + projectName + ' to bind Assets...'

os.system("/Applications/Unity/Unity.app/Contents/MacOS/Unity -quit -batchmode -projectPath " + rootPath + projectName)

time.sleep(20)


print "Exporting package:" + outputFileName
os.system("/Applications/Unity/Unity.app/Contents/MacOS/Unity -quit -batchmode -nographics -projectPath " + rootPath + projectName + " -exportPackage " + "Assets " + outputFileName)



print 'Operation Complete!'

